<!--footer start-->
<footer style="background-color:#C0C0C0;line-height: 20px;height: auto;margin-top:130px ;">
    <div class="text-center">
         &copy; Copyright Careerpaths NW
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
