<?php 
	if(isset($view_file)) {$this->load->view($view_file);}	
?>
