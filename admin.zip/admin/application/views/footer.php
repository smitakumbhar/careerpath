<!--footer start-->
<footer class="site-footer">
    <div class="text-center">
         &copy; Copyright Careerpaths NW
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->